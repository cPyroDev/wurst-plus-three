---
name: Question
about: Ask a question about the client. Try asking in the discord server first. discord.gg/wurst
title: "[QUESTION]"
labels: ''
assignees: ''

---

**Question**
Ask your question and include as much relevant information as possible.
