![logo](src/main/resources/logo.png)

# Wurst+3 

<img src="https://img.shields.io/github/downloads/WurstPlus/wurst-plus-three/total" alt="dwnlds" />

[Discord](https://discord.com/invite/hvnZePKQHx) | [Donate](https://paypal.me/trvsf) | [Download](https://github.com/TrvsF/wurst-plus-three/releases/latest)

1.12.2 forge minecraft client

Made for crystalpvp and killing noobs.

On first run ensure your voices volume is maxed ;)

[CoC](CODE_OF_CONDUCT.md)

## Donations

Join the discord for more infomation.

2 Boosts in discord OR $5 for 1 month 'cool dudes' cape.

10 boosts in discord OR $15 for lifetime custom cape.

To donate use link above and make sure your discord tag is included in the comments, then DM travis#0001 on discord.

Nitro boosts capes will be given ASAP.

## Credits

the usual suspects are here, [phobos](https://github.com/Hqrion/Phobos-1.9.0-BUILDABLE-SRC), [gamesense](https://github.com/IUDevman/gamesense-client), some [xulu](https://github.com/Elementars/Xulu-v1.5.2), and other misc stuff. if you want better credit dm me on discord travis#0001

Also the old gui is using [panel studio](https://github.com/lukflug/PanelStudio/)

## Why

Got bored pt. 3, began work as a project for my friends to pvp, turned into this

## How

Download the latest release or build yourself, put file into your mods folder and run with forge 1.12.2

## Build

If you want to compile your own binaries use the following commands


```bash
./gradlew setupdecompworkspace
./gradlew build
```

## Usage

Right shift opens the GUI

'.' is the default prefix, to change this go to .minecraft\Wurstplus3\configs\default\BINDS.txt and change the top line

For a list of commands [click here](Commands.md)

## Contributing
Make a pull request, would be preferable if you joined the discord before hand

For a guide on contributing please [click here](CONTRIBUTING.md) 
