package me.travis.wurstplusthree.gui.alt.defult;

import net.minecraft.client.gui.GuiButton;

/**
 * @author Madmegsox1
 * @since 23/05/2021
 */

public class GuiAltButton extends GuiButton {

    public GuiAltButton(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
        super(buttonId, x, y, widthIn, heightIn, buttonText);
    }
}
