package me.travis.wurstplusthree.event.processor;

/**
 * @author Madmegsox1
 * @since 04/06/2021
 */

public enum EventPriority {
    HIGH,
    NONE,
    LOW
}
