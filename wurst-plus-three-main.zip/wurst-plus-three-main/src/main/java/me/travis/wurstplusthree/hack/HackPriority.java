package me.travis.wurstplusthree.hack;

public enum HackPriority {
    Highest,
    High,
    Normal,
    Low,
    Lowest
}
