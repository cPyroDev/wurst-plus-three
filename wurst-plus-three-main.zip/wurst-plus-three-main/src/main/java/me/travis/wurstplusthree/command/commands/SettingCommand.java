package me.travis.wurstplusthree.command.commands;

public class SettingCommand { // TODO : THIS
}
