# Contributing Guide

For all contributions we will be looking for properly formatted code for 
example var names with Camel Casing
```java
//NOT TODO
int my_var_name = 0;
//TODO
int myVarName = 0;
```

Any contributions to the base of the client must be done in java but any
contributions to Models can be done or java!

Before you contribute you must test your code for bugs!

Please try to do small contributions so merging is easier!

Please use the active brach that is not main e.g. 0.6.0 because if there was a file edited in that branch that was editied in you PR we cannot accept the PR

Also join the discord to see the #todo section

Finally, please don't write china code!!!!!

Unless your me >:)
